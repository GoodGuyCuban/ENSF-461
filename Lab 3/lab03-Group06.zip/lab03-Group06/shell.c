#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include "parser.h"

#define BUFLEN 1024

char* get_command_path(char* command) {
    char* path = getenv("PATH");
    char* path_copy = strdup(path);
    char* path_token = strtok(path_copy, ":");

    while (path_token != NULL) {
        char* command_path = (char*) malloc(BUFLEN * sizeof(char));
        sprintf(command_path, "%s/%s", path_token, command);

        if (access(command_path, X_OK) == 0) {
            free(path_copy);
            return command_path;
        }

        free(command_path);
        path_token = strtok(NULL, ":");
    }

    free(path_copy);
    return NULL;
}

int main() {
    char buffer[1024];
    char* parsedinput;
    char* args[3];
    char newline;

    printf("Welcome to the GroupXX shell! Enter commands, enter 'quit' to exit\n");
    do {
        //Print the terminal prompt and get input
        printf("$ ");
        char *input = fgets(buffer, sizeof(buffer), stdin);
        if(!input)
        {
            fprintf(stderr, "Error reading input\n");
            return -1;
        }
        
        //Clean and parse the input string
        parsedinput = (char*) malloc(BUFLEN * sizeof(char));
        strncpy(parsedinput, buffer, BUFLEN);
        parsedinput[strcspn(parsedinput, "\n")] = '\0';

        //Tokenize the input string
        args[0] = strtok(parsedinput, " ");
        args[1] = strtok(NULL, " ");
        args[2] = NULL;

        //Check if the command is in the PATH
        char* command_path = get_command_path(args[0]);
        if (command_path == NULL) {
            printf("Command not found\n");
            continue;
        }

        //Fork a child process to execute the command
        pid_t pid = fork();
        if (pid == -1) {
            fprintf(stderr, "Error forking process\n");
            return -1;
        } else if (pid == 0) {
            //Child process
            execv(command_path, args);
            fprintf(stderr, "Error executing command\n");
            return -1;
        } else {
            //Parent process
            wait(NULL);
        }

        free(command_path);
    } while (strncmp(buffer, "quit", 4) != 0);

    return 0;
}